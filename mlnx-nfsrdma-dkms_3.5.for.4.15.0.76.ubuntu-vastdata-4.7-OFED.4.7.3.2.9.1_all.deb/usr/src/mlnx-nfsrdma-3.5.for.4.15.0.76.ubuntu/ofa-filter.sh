#!/bin/bash

set -eux

rm -rf $2/.ofa_kernel
cp -as $1 $2/.ofa_kernel
rm -rf $2/.ofa_kernel/include/linux/sunrpc
touch $2/.ofa_kernel/.done
