#define NFS_BUNDLE_VERSION "3.7.rc8.for.5.4.0.48.52.ubuntu-vastdata-5.1-OFED.5.1.2.4.6.1"
