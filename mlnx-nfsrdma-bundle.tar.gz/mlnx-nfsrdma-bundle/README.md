# VAST NFS source

This repository is used to create a source package for VAST NFS, that can build
based on kernel and distribution detection. There is a collection of separate
Git branches per supported kernel, from which this source package is built.

Current package version: v3.7-rc8

See [Change Log](ChangeLog.md).

See [INSTALL](INSTALL.md) file for list of supported kernels and instructions
relevant to execution on client machines.


## Source package

To build the source package of this Git repository, run:

	./build.sh src

The result source package will reside in the `src-dist` directory.

For example:

```
# ./build.sh src
Creating nfsrdma-vastdata-3.3 from Git repository versions

Output in src-dist directory:

total 868
-rw-rw-r--. 1 dan dan 888528 Jul 20 17:19 nfsrdma-vastdata-3.3.tar.xz
```

### Building a binary package using the source package

Binary packages can be built using the source package without using Git, by
using `make` following extraction of the source package, inside the source
package. If the kernel, distribution, or OFED are not supported, an error will
be printed.

```
$ tar -xf nfsrdma-vastdata-3.3.tar.xz
$ cd nfsrdma-vastdata-3.3
$ make
...

Output in dist/

total 764
-rw-r--r-- 1 user user 779272 Jul 20 14:22 mlnx-nfsrdma-modules_3.3.for.5.3.0.53.ubuntu-vastdata-5.0-OFED.5.0.2.1.8.1.kver.5.3.0-53-generic_amd64.deb
```


## Binary package

To build a binary from this Git repository for the current kernel and OFED
versions, run `./build.sh bin`, and take the output from the `dist` directory.
If the kernel, distribution, or OFED are not supported, an error will be
printed.

```
$ ./build.sh bin
...

Output in dist/

total 760
-rw-r--r-- 1 user user 777512 Jul 20 14:25 mlnx-nfsrdma-modules_3.3.for.5.3.0.53.ubuntu-vastdata-5.0-OFED.5.0.2.1.8.1.kver.5.3.0-53-generic_amd64.deb
```
