# v3.7-rc8

* Support three more kernels.
* Allow to build RPMs for a kernel that is currently not running.
* Fix for SUSE's "supported modules" verification, flagging the kernel modules
  as "externally supported".

# v3.7-rc7

* Support for select CentOS 7.x kernels, and latest CentOS 8.2.
* SLES 12 SP5 support.
* NFS: Differentiate mounts based on multipath parameters.
* NFS: Client fixes for directory listing.
* Fixes related to OFED 5.1.
* File handle based transport selection (enabled by default only for READ/WRITE).
* A fix for the mount command in a boot session, not properly waiting for
  `rpcrdma` to load.
* Shared XID between transport. This is a protocol detail to improve caching
  correctness in fail-over cases.
* Workaround IB bug related to address resolution.


# v3.6

* Fix for missing module `rpcsec_gss_krb5.ko` in install.


# v3.5

* Fix GDS for disconnections during IOs. This is actually an upstream bug that
  manifests itself more greatly with the GDS integration, which relies on
  buffers being unmapped.


# v3.4

* Workaround for NFS direct IO with GDS. The issue is that a bad interaction
  with the NVidia GDS base 0.7.1 when the process is killed with the IOs return
  with `ERESTARTSYS`, causing an unreleased mutex in the Nvidia propritary driver
  that causes invocations of other users such as `nvidia-smi` to get stuck.


# v3.3

* Build scripts improvement for supporting multiple kernel versions. Currently
  supporting two Ubuntu kernels. Source package detects the kernel version
  currently installed and builds the right version.


# v3.2

* Fix for TCP mount. The TCP support does not yet extend to multipath like it
   does for RDMA.


# v3.1

* Support fore more than 8 multipath ports.


# v3.0

 * Initial versions supporting Multipath and GDS integration.
