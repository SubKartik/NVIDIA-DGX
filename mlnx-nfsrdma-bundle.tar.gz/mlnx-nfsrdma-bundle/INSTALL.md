# VAST NFS client driver package

This package provides a modified version of the NFS client and server kernel
code, designed to be built following installation of the Mellanox OFED.

There are multitude of improvements:

- Upstream SunRPC and RPC-RDMA code from Linux 5.8-rc2, with fixes for
  stability. This addresses many stability bugs of RPCRDMA in older
  kernels.
- Enhanced improved multipath and high-availability support for SunRPC and
  RPC-RDMA.
- Important NFS client fixes for improved experience.
- Experimental Nvidia GDS integration.


# Supported kernel versions

| Distribution     | Kernel version    |
| ---              |  ------           |
| CentOS/RHEL 8.2  | 4.18.0-18.19      |
| CentOS/RHEL 7.8  | 3.10.0-1127.19.1  |
| CentOS/RHEL 7.8  | 3.10.0-1127       |
| CentOS/RHEL 7.6  | 3.10.0-957.27.2   |
| CentOS/RHEL 7.6  | 3.10.0-957.10.1   |
| CentOS/RHEL 7.5  | 3.10.0-862.3.3    |
| SLES 12 SP5      | 4.12.14-122.37    |
| Ubuntu           | 5.4.0-52          |
| Ubuntu           | 5.4.0-48          |
| Ubuntu           | 5.4.0-47          |
| Ubuntu           | 5.4.0-45          |
| Ubuntu           | 5.4.0-42          |
| Ubuntu           | 5.3.0-59          |
| Ubuntu           | 5.3.0-53          |
| Ubuntu           | 4.18.0-18         |
| Ubuntu           | 4.15.0-117        |
| Ubuntu           | 4.15.0-76         |


# Generating binary packages

To generate the binary packages, please run:

```
./build.sh bin
```

The resulting binary will reside in `./dist` sub-directory.


# Installation

## CentOS 7.x and CentOS 8.x

Install:
```
sudo yum install ./dist/mlnx-nfsrdma-vast*.x86_64.rpm
```

Verify that the package is indeed installed (versions should match):

```
rpm -qa | grep mlnx-nfsrdma
```

To further validate installation, verify that `rpcrdma` in the right path
exists and get loaded from it.  All the added kernel modules go under
`updates/bundle`:

```
rpm -qif /lib/modules/`uname -r`/extra/mlnx-nfsrdma/bundle/net/sunrpc/xprtrdma/rpcrdma.ko
```

```
$ modinfo rpcrdma | grep filename:
filename:       /lib/modules/..../extra/mlnx-nfsrdma/bundle/net/sunrpc/xprtrdma/rpcrdma.ko
```

## Ubuntu

Install:

```
sudo apt-get install ./dist/mlnx-nfsrdma-modules_*-generic_amd64.deb
sudo update-initramfs -u -k `uname -r`
```

Verify that the package is indeed installed (versions should match):

```
dpkg -l | grep mlnx-nfsrdma-modules
```

To further validate installation, verify that `rpcrdma` in the right path
exists and get loaded from it.  All the added kernel modules go under
`updates/bundle`:

```
dpkg -S /lib/modules/`uname -r`/updates/bundle/net/sunrpc/xprtrdma/rpcrdma.ko
```



# Multipath configuration

Multipath is supported using source routing, where multiple network legs are
configured with IP addresses on the same Infiniband or RoCE subnet. Local ports
are the egress ports from the client, and remote ports are the ingress ports of
the server.

In order to make use of NFSv3 multipath provided in this package, configuration
is needed depending on Linux distribution.


## CentOS 7.x

Here we demonstrate multipath with two local interfaces on the same subnet.

First we need to install `NetworkManager-config-routing-rules`.

`yum install NetworkManager-config-routing-rules`

We configure new source routing tables:

```
echo '101 101' >> /etc/iproute2/rt_tables
echo '102 102' >> /etc/iproute2/rt_tables
```

For this example we assume two interfaces are configured via `ifcfg-` scripts:

```
$ grep IPADDR /etc/sysconfig/network-scripts/ifcfg-ib0
IPADDR=192.168.40.1
$ grep IPADDR /etc/sysconfig/network-scripts/ifcfg-ib1
IPADDR=192.168.40.2
```

For each interface we need to add a `route-` and `rule-` files:

```
$ cat /etc/sysconfig/network-scripts/route-ib0
192.168.40.0/24 via 192.168.40.1 table 101
$ cat /etc/sysconfig/network-scripts/rule-ib0
from 192.168.40.1/32 table 101
```

NOTE: This is only an example. The IP addresses you pick depend on your network
configuration.

After reloading with `nmcli connection reload`, the `ip` command with regard to routing
should look like this (notice the two added `lookup` lines):
```
$ ip rule
0:      from all lookup local
32764:  from 192.168.40.1 lookup 101
32765:  from 192.168.40.2 lookup 102
32766:  from all lookup main
32767:  from all lookup default

$ ip route show table 101
192.168.40.0/24 via 192.168.40.1 dev ib0

$ ip route show table 102
192.168.40.0/24 via 192.168.40.2 dev ib1
```

Verify that the IPs and routing tables appear correctly.  Below are examples
which will vary based on environment:

IP addresses:

```
$ ip a s | grep 192.168.40

    inet 192.168.40.1/24 brd 192.168.40.255 scope global ib0
    inet 192.168.40.2/24 brd 192.168.40.255 scope global ib1
```

## Ubuntu 18

Ubuntu installations can use `netplan` to specify the network configuration.
For each port, we need to have one IP address in the subnet. For each IP
address, source routing needs to be enabled.

For example, in the updated `01-netcfg.yml` for local port configuration (`ib0`,
`ib1`, `ib2`, `ib3`), _append_ `routes` and `routing-policy` rules:

```
    ib0:
        dhcp4: no
        addresses: [172.25.1.101/24]
        routes:
         - to: 172.25.1.0/24
           via: 172.25.1.101
           table: 101
        routing-policy:
         - from: 172.25.1.101
           table: 101
    ib1:
        dhcp4: no
        addresses: [172.25.1.102/24]
        routes:
         - to: 172.25.1.0/24
           via: 172.25.1.102
           table: 102
        routing-policy:
         - from: 172.25.1.102
           table: 102
    ib2:
        dhcp4: no
        addresses: [172.25.1.103/24]
        routes:
         - to: 172.25.1.0/24
           via: 172.25.1.103
           table: 103
        routing-policy:
         - from: 172.25.1.103
           table: 103
    ib3:
        dhcp4: no
        addresses: [172.25.1.104/24]
        routes:
         - to: 172.25.1.0/24
           via: 172.25.1.104
           table: 104
        routing-policy:
         - from: 172.25.1.104
           table: 104
```

NOTE: This is only an example. The IP addresses you pick depend on your network
configuration.

The apply the new configuration, run:

```
sudo netplan apply
```

Verify that the IPs and routing tables appear correctly.  Below are examples which will vary based on environment:

IP addresses:

```
$ ip a s | grep 172.25.1

    inet 172.25.1.101/20 brd 172.25.1.255 scope global ib0
    inet 172.25.1.102/20 brd 172.25.1.255 scope global ib1
    inet 172.25.1.103/20 brd 172.25.1.255 scope global ib2
    inet 172.25.1.104/20 brd 172.25.1.255 scope global ib3

```

Routing tables:

```
$ for i in 101 103 102 104; do ip route show table $i; done;

172.25.1.0/20 via 172.25.1.101 dev ib0 proto static
172.25.1.0/20 via 172.25.1.102 dev ib1 proto static
172.25.1.0/20 via 172.25.1.103 dev ib2 proto static
172.25.1.0/20 via 172.25.1.104 dev ib3 proto static
```

## Verification

Reboot, to ensure that this version is loaded correctly.

Once rebooted, and to verify fully once it is loaded, for each kernel module,
loaded version should match installed version. For example:

```
$ cat /sys/module/sunrpc/srcversion
4CC8389C7889F82F5A59269

$ modinfo sunrpc | grep srcversion
srcversion:     4CC8389C7889F82F5A59269
```

(This is only an example - srcversion is different for each build and kernel module).



# Mounting a remote file system

Based on the IP source routing configuration, extra parameters are needed to
utilize the configuration in the mount path.

This is an example mount commands (4 local ports to 8 remote ports):

```
sudo mount -o proto=rdma,port=20049,vers=3,nconnect=8,noidlexprt,localports=172.25.1.101-172.25.1.104,remoteports=172.25.1.1-172.25.1.8 172.25.1.1:/ /mnt/nfs
```

The code changes in this repository add the following parameters:

	noidlexprt    Do not disconnect idle connections. This to detect and
	              recover failing ones when there are no pending I/Os.
	localports    A list of IPv4 addresses for the local ports to bind
	remoteports   A list of IPv4 addresses for the remote ports to bind

IP addresses can be given as an inclusive range, with `-` as a delimiter, e.g.
`FIRST-LAST`. Multiple ranges or IP addresses can be separated by `~`.


# Monitoring

Normally, `mountstats` under `/proc` shows `xprt` statistics. However, instead
of modifying it in a non-compatible way with the `nfsstat` utility, we have
extended `mountstats` with our own extra state reporting, to be exclusively to
accessed from `/sys/kernel/debug`.

Thus, the `stats` node was added, per RPC client. Usually, the RPC client 0
shows the single mount being done:

E.g. `sudo cat /sys/kernel/debug/sunrpc/rpc_clnt/0/stats`

The added information is multipath IP address information per xprt and xprt
state in string format.

For example:

```
        xprt:   rdma 0 0 1 0 24 3 3 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 11 0 0 0
                172.25.1.101 -> 172.25.1.1, state: CONNECTED BOUND
        xprt:   rdma 0 0 1 0 24 1 1 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 11 0 0 0
                172.25.1.102 -> 172.25.1.2, state: CONNECTED BOUND
        xprt:   rdma 0 0 1 0 23 1 1 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 11 0 0 0
                172.25.1.103 -> 172.25.1.3, state: CONNECTED BOUND
        xprt:   rdma 0 0 1 0 22 1 1 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 11 0 0 0
                172.25.1.104 -> 172.25.1.4, state: CONNECTED BOUND
        xprt:   rdma 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
                172.25.1.101 -> 172.25.1.5, state: BOUND
        xprt:   rdma 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
                172.25.1.102 -> 172.25.1.6, state: BOUND
        xprt:   rdma 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
                172.25.1.103 -> 172.25.1.7, state: BOUND
        xprt:   rdma 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
                172.25.1.104 -> 172.25.1.8, state: BOUND
```
