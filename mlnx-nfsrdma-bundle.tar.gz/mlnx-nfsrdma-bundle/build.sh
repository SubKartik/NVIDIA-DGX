#!/bin/bash

declare -A VERSIONS PATCH

# Version of the source package
VERSION=3.7-rc8

# CentOS 7
VERSIONS[3.10.0-862.3.3.el7.x86_64.centos]=v${VERSION}.for.3.10.0-862.3.3.centos
VERSIONS[3.10.0-957.27.2.el7.x86_64.centos]=v${VERSION}.for.3.10.0-957.27.2.centos
PATCH[3.10.0-957.27.2.el7.x86_64.centos]=3.10.0-862.3.3.el7.x86_64.centos
VERSIONS[3.10.0-957.10.1.el7.x86_64.centos]=v${VERSION}.for.3.10.0-957.10.1.centos
PATCH[3.10.0-957.10.1.el7.x86_64.centos]=3.10.0-862.3.3.el7.x86_64.centos
VERSIONS[3.10.0-1127.19.1.el7.x86_64.centos]=v${VERSION}.for.3.10.0-1127.19.1.centos
PATCH[3.10.0-1127.19.1.el7.x86_64.centos]=3.10.0-862.3.3.el7.x86_64.centos
VERSIONS[3.10.0-1127.el7.x86_64.centos]=v${VERSION}.for.3.10.0-1127.centos
PATCH[3.10.0-1127.el7.x86_64.centos]=3.10.0-862.3.3.el7.x86_64.centos

# CentOS 8
VERSIONS[4.18.0-193.19.1.x86_64.centos]=v${VERSION}.for.4.18.0-193.19.1.centos

# SLES 12
VERSIONS[4.12.14-122.37.sles]=v${VERSION}.for.4.12.14-122.37.sles

# Ubuntu
VERSIONS[4.15.0-76-generic.ubuntu]=v${VERSION}.for.4.15.0-76.86.ubuntu
VERSIONS[4.15.0-117-generic.ubuntu]=v${VERSION}.for.4.15.0-117.118.ubuntu
VERSIONS[4.18.0-18-generic.ubuntu]=v${VERSION}.for.4.18.0-18.19.ubuntu

VERSIONS[5.3.0-53-generic.ubuntu]=v${VERSION}.for.5.3.0-53.47.ubuntu
VERSIONS[5.3.0-59-generic.ubuntu]=v${VERSION}.for.5.3.0-59.53.ubuntu
PATCH[5.3.0-59-generic.ubuntu]=5.3.0-53-generic.ubuntu

VERSIONS[5.4.0-42-generic.ubuntu]=v${VERSION}.for.5.4.0-42.46.ubuntu
VERSIONS[5.4.0-45-generic.ubuntu]=v${VERSION}.for.5.4.0-47.51.ubuntu # Compatible
VERSIONS[5.4.0-47-generic.ubuntu]=v${VERSION}.for.5.4.0-47.51.ubuntu
VERSIONS[5.4.0-48-generic.ubuntu]=v${VERSION}.for.5.4.0-48.52.ubuntu # Compatible
VERSIONS[5.4.0-52-generic.ubuntu]=v${VERSION}.for.5.4.0-48.52.ubuntu # Compatible
PATCH[5.4.0-45-generic.ubuntu]=5.4.0-42-generic.ubuntu
PATCH[5.4.0-47-generic.ubuntu]=5.4.0-42-generic.ubuntu
PATCH[5.4.0-48-generic.ubuntu]=5.4.0-42-generic.ubuntu
PATCH[5.4.0-52-generic.ubuntu]=5.4.0-42-generic.ubuntu

src() {
	set -e

	RDIR=$(mktemp -d -t nfsrdma-buildsh-XXXXXXXXXX)
	NAME=nfsrdma-vastdata-${VERSION}

	echo Stand by - creating nfsrdma-vastdata-${VERSION}.tar.xz from Git repository versions...

	TDIR=${RDIR}/${NAME}

	rm -rf src-dist
	mkdir src-dist

	mkdir ${TDIR}
	cp ${BASH_SOURCE} ${TDIR}
	cp .gitignore ${TDIR}
	echo -e 'all:\n\t./build.sh bin' > ${TDIR}/Makefile

	mkdir -p ${TDIR}/src
	for key in ${!VERSIONS[@]} ; do
		version=${VERSIONS[${key}]}
		patch_base=${PATCH[${key}]}
		if [[ "${patch_base}" == "" ]] ; then
			git archive --format=tar --prefix=src/${key}/ ${version} |\
				tar -xf - -C ${TDIR}
		else
			version_base=${VERSIONS[${patch_base}]}
			git diff ${version_base}..${version} >\
				${TDIR}/src/${key}.diff
		fi

		git show ${version}:git-version.sh > git-version.sh
		chmod a+x git-version.sh
		./git-version.sh ${version} > ${TDIR}/src/${key}.version
		rm -f git-version.sh
	done

	DF=$(realpath src-dist)/nfsrdma-vastdata-${VERSION}.tar.xz
	cp INSTALL.md ${TDIR}/
	tar -cf - -C ${RDIR} ${NAME} | xz -T 16 -9 > ${DF}

	echo
	echo "Output in src-dist directory:"
	echo
	ls -l src-dist

	rm -rf ${TDIR}
	rmdir ${RDIR}
}

bin() {
	source /etc/os-release

	local kver=${KVER:-`uname -r`}
	local script

	if [[ "$ID" == "ubuntu" ]] ; then
		script=build-deb.sh
	elif [[ "$ID" == "centos" ]] ; then
		script=build-rpm.sh
	elif [[ "$ID" == "sles" ]] ; then
		script=build-rpm.sh
	elif [[ "$ID" == "opensuse" ]] ; then
		script=build-rpm.sh
		ID=sles
	else
		echo 'The Linux distribution of type '${ID}' not supported.'
		exit -1
	fi

	local key=${kver}.${ID}
	local version=${VERSIONS[${key}]}

	if [[ "${version}" == "" ]] ; then
		echo "Kernel ${kver} not supported on distribution ${ID}."
		exit -1
	fi

	local patch_base=${PATCH[${key}]}

	echo "Preparing source for kernel version"

	set -e
	set -u

	rm -rf build/
	if [[ "${patch_base}" == "" ]] ; then
		if [[ -d src/${key} ]] ; then
			cp -a src/${key} build
			cp src/${key}.version build/.git-version-save
		else
			git archive --format=tar --prefix=build/ ${version} | \
				tar -xf -
			build/git-version.sh ${version} > build/.git-version-save
		fi
	else
		if [[ -e "src/${key}.diff" ]] && [[ -d "src/${patch_base}" ]] ; then
			cp -a src/${patch_base} build
			cat src/${key}.diff | (cd build && patch -p1 > /dev/null)
			cp src/${key}.version build/.git-version-save
		else
			git archive --format=tar --prefix=build/ ${version} | \
				tar -xf -
			build/git-version.sh ${version} > build/.git-version-save
		fi
	fi

	cd build
	./${script}
	cd ..

	if [[ "$script" == "build-deb.sh" ]] ; then
		rm -rf dist/
		mv build/deb-dist dist/
	elif [[ "$script" == "build-rpm.sh" ]] ; then
		rm -rf dist/
		mv build/rpm-dist dist/
	fi

	echo "------------------------------------------------------------------"
	echo
	echo "Output in dist/"
	echo

	ls -l dist/
}

help() {
	echo "Syntax:"
	echo ""
	echo "   ./build.sh bin"
	echo "        Build a package for the current kernel"

	unset GIT_DIR
	GDIR=$(git rev-parse --git-dir 2>/dev/null)
	if [[ "$GDIR" == ".git" ]] ; then
		echo ""
		echo "   ./build.sh src"
		echo "        Build a multi-kernel source package current current Git repository state"
	fi

}

if [[ "$@" == "" ]] ; then
	help
else
	"$@"
fi
