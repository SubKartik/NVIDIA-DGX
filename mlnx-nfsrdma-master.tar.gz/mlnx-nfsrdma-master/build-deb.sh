#!/bin/bash

set -e
set -u

git archive HEAD -o ../mlnx-nfsrdma_4.5.orig.tar.gz

git clean -xdf debian/

dpkg-buildpackage -uc -us

rm -rf deb-dist
mkdir deb-dist
mv ../mlnx-nfsrdma-dkms_4.5-OFED.4.5.1.0.1.1.gb4fdfac.multikernel.vastdata_all.deb ./deb-dist

rm -f ../mlnx-nfsrdma_4.5.orig.tar.gz
rm -f ../mlnx-nfsrdma_4.5-OFED.4.5.1.0.1.1.gb4fdfac.multikernel.vastdata{.debian.tar.xz,.dsc,_amd64.{buildinfo,changes}}

