#!/bin/bash

make "$@" BASE_DIR=$(pwd)
