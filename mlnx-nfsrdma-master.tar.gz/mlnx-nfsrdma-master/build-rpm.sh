#!/bin/bash

set -e

OFED_RELEASE=$(rpm -qa | grep ^mlnx-ofa_kernel-devel | \
	awk -F"-OFED" '{print "OFED"$2}' | awk -F".g" '{print $1}')

VERSION=vast_$(git describe HEAD | cut -c2- | tr - _)

make srcrpm BASE_DIR=$(pwd) RELEASE=${OFED_RELEASE} VERSION=${VERSION}
make binrpm BASE_DIR=$(pwd) RELEASE=${OFED_RELEASE} VERSION=${VERSION}
