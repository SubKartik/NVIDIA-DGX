#!/usr/bin/env python3

import os

files = """
backchannel.c
fmr_ops.c
frwr_ops.c
module.c
rpc_rdma.c
rpcrdma_dummy.c
svc_rdma.c
svc_rdma_backchannel.c
svc_rdma_recvfrom.c
svc_rdma_rw.c
svc_rdma_sendto.c
svc_rdma_transport.c
svcrdma_dummy.c
transport.c
verbs.c
xprt_rdma.h
xprtrdma_dummy.c
physical_ops.c
svc_rdma_marshal.c
"""

VERSIONS = [
    ("2_6_32_centos_6_9",      "2.6.32-696.30.1.el6"),
    ("3_10_0_pre_centos_7_4",  "3.10.0-693.el7"),
    ("3_10_0_centos_7_4",      "3.10.0-693.el7"),
    ("3_10_0_centos_7_5",      "3.10.0-862.el7"),
    ("3_10_0_centos_7_6",      "3.10.0-957.12.2.el7"),
    ("3_10_0_centos_7_7",      "3.10.0-1062.el7"),
    ("3_10_0_post_centos_7_7", "3.10.0-1062.el7"),
    ("4_4_pre_165",            "4.4.162-94.72.suse"),
    ("4_4_post_165",           "4.4.165-81.suse"),
    ("4_12_15_95",             "4.12.14-95.45.1-suse"),
    ("4_15_0_76",              "4.15.0-76.86.ubuntu"),
    ("4_15_0_52",              "4.15.0-52.56.ubuntu"),
    ("5_0_0_37",               "5.0.0-37.40.ubuntu"),
]

for filename in files.strip().split():
    for (marker, srcdir) in VERSIONS:
        subdir = "src-" + srcdir
        subfile = os.path.join(subdir, filename)
        if os.path.exists(subfile):
            incvar = f"""#include "{subfile}\""""
        else:
            incvar = ""
        locals()[f"kernel_{marker}_include"] = incvar

    print(f"""
#include <linux/version.h>

#if (defined(RHEL_MAJOR) && RHEL_MAJOR == 6)
  {kernel_2_6_32_centos_6_9_include}
#elif (defined(RHEL_MAJOR) && RHEL_MAJOR == 7)
  #if (RHEL_MINOR < 4)
    {kernel_3_10_0_pre_centos_7_4_include}
  #elif (RHEL_MINOR == 4)
    {kernel_3_10_0_centos_7_4_include}
  #elif (RHEL_MINOR == 5)
    {kernel_3_10_0_centos_7_5_include}
  #elif (RHEL_MINOR == 6)
    #include <linux/iommu.h>

    #ifdef IOMMU_RESV_DIRECT
    #define RHEL7_SUB_MINOR 27
    #else
    #define RHEL7_SUB_MINOR 26
    #endif

    {kernel_3_10_0_centos_7_6_include}
  #elif (RHEL_MINOR == 7)
    {kernel_3_10_0_centos_7_7_include}
  #else
    {kernel_3_10_0_post_centos_7_7_include}
  #endif
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(4,12,0) && \
       LINUX_VERSION_CODE < KERNEL_VERSION(4,13,0))
{kernel_4_12_15_95_include}
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(4,15,0) && \
       LINUX_VERSION_CODE < KERNEL_VERSION(4,16,0))
#include <generated/utsrelease.h>

#if UTS_UBUNTU_RELEASE_ABI < 76
{kernel_4_15_0_52_include}
#else
{kernel_4_15_0_76_include}
#endif

#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(5,0,0) && \
       LINUX_VERSION_CODE < KERNEL_VERSION(5,1,0))
#include <generated/utsrelease.h>

{kernel_5_0_0_37_include}

#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(4,4,0) && \
       LINUX_VERSION_CODE < KERNEL_VERSION(4,5,0))
  #if (LINUX_VERSION_CODE >= KERNEL_VERSION(4,4,165))
  {kernel_4_4_post_165_include}
  #else
  {kernel_4_4_pre_165_include}
  #endif
#else
#error "Unknown kernel version"
#endif
    """.strip() + "\n", file=open(filename, "w"))
