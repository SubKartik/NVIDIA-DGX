#include <linux/version.h>

#if (defined(RHEL_MAJOR) && RHEL_MAJOR == 6)
  
#elif (defined(RHEL_MAJOR) && RHEL_MAJOR == 7)
  #if (RHEL_MINOR < 4)
    
  #elif (RHEL_MINOR == 4)
    
  #elif (RHEL_MINOR == 5)
    
  #elif (RHEL_MINOR == 6)
    #include <linux/iommu.h>

    #ifdef IOMMU_RESV_DIRECT
    #define RHEL7_SUB_MINOR 27
    #else
    #define RHEL7_SUB_MINOR 26
    #endif

    #include "src-3.10.0-957.12.2.el7/svcrdma_dummy.c"
  #elif (RHEL_MINOR == 7)
    
  #else
    
  #endif
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(4,12,0) &&        LINUX_VERSION_CODE < KERNEL_VERSION(4,13,0))

#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(4,15,0) &&        LINUX_VERSION_CODE < KERNEL_VERSION(4,16,0))
#include <generated/utsrelease.h>

#if UTS_UBUNTU_RELEASE_ABI < 76
#include "src-4.15.0-52.56.ubuntu/svcrdma_dummy.c"
#else

#endif

#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(5,0,0) &&        LINUX_VERSION_CODE < KERNEL_VERSION(5,1,0))
#include <generated/utsrelease.h>



#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(4,4,0) &&        LINUX_VERSION_CODE < KERNEL_VERSION(4,5,0))
  #if (LINUX_VERSION_CODE >= KERNEL_VERSION(4,4,165))
  
  #else
  
  #endif
#else
#error "Unknown kernel version"
#endif

