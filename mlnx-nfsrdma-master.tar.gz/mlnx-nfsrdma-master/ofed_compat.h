#ifndef __OFED_COMPAT_H__
#define __OFED_COMPAT_H__

#include <rdma/ib_verbs.h>
#include <rdma/rdma_vt.h>

#ifdef INIT_RDMA_OBJ_SIZE
#define OFED_4_7
#define OFED_4_6
#elif defined(RVT_SGE_COPY_MEMCPY)
#define OFED_4_6
#endif

#ifdef OFED_4_7
#define compat_ib_device_ops(device, name) ((device)->ops.name)
#else
#define compat_ib_device_ops(device, name) ((device)->name)
#endif

#ifdef OFED_4_6

static inline int ib_device_attr__max_send_sge(const struct ib_device_attr *attr) {
    return attr->max_send_sge;
}
static inline int ib_device_attr__max_sge(const struct ib_device_attr *attr) {
    return min(attr->max_send_sge, attr->max_recv_sge);
}

#else

static inline int ib_device_attr__max_send_sge(const struct ib_device_attr *attr) {
    return attr->max_sge;
}
static inline int ib_device_attr__max_sge(const struct ib_device_attr *attr) {
    return attr->max_sge;
}

#endif

#endif
