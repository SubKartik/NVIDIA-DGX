#include <linux/version.h>

#if (defined(RHEL_MAJOR) && RHEL_MAJOR == 6)
  #include "src-2.6.32-696.30.1.el6/module.c"
#elif (defined(RHEL_MAJOR) && RHEL_MAJOR == 7)
  #if (RHEL_MINOR < 4)
    #include "src-3.10.0-693.el7/module.c"
  #elif (RHEL_MINOR == 4)
    #include "src-3.10.0-693.el7/module.c"
  #elif (RHEL_MINOR == 5)
    #include "src-3.10.0-862.el7/module.c"
  #elif (RHEL_MINOR == 6)
    #include <linux/iommu.h>

    #ifdef IOMMU_RESV_DIRECT
    #define RHEL7_SUB_MINOR 27
    #else
    #define RHEL7_SUB_MINOR 26
    #endif

    #include "src-3.10.0-957.12.2.el7/module.c"
  #elif (RHEL_MINOR == 7)
    #include "src-3.10.0-1062.el7/module.c"
  #else
    #include "src-3.10.0-1062.el7/module.c"
  #endif
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(4,12,0) &&        LINUX_VERSION_CODE < KERNEL_VERSION(4,13,0))
#include "src-4.12.14-95.45.1-suse/module.c"
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(4,15,0) &&        LINUX_VERSION_CODE < KERNEL_VERSION(4,16,0))
#include <generated/utsrelease.h>

#if UTS_UBUNTU_RELEASE_ABI < 76
#include "src-4.15.0-52.56.ubuntu/module.c"
#else
#include "src-4.15.0-76.86.ubuntu/module.c"
#endif

#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(5,0,0) &&        LINUX_VERSION_CODE < KERNEL_VERSION(5,1,0))
#include <generated/utsrelease.h>



#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(4,4,0) &&        LINUX_VERSION_CODE < KERNEL_VERSION(4,5,0))
  #if (LINUX_VERSION_CODE >= KERNEL_VERSION(4,4,165))
  #include "src-4.4.165-81.suse/module.c"
  #else
  #include "src-4.4.162-94.72.suse/module.c"
  #endif
#else
#error "Unknown kernel version"
#endif

