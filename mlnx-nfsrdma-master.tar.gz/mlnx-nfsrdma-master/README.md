# Multi-kernel and Multi-OFED nfsrdma support

Under Linux `rpcrdma` is a kernel component needed for a functioning NFS RDMA
setup

In order for `rpcrmda` to co-exist with Mellanox OFED, it must be recompiled
after Mellanox OFED is installed on a system.

The packages that can be generated from this repository contain the rpcrdma
select support for various kernels under a varying set of Mellanox OFED
releases.

# Official support matrix

The package supports the following OFED versions:

* OFED 4.4
* OFED 4.5
* OFED 4.6
* OFED 4.7

The package supports the following kernel versions (wildcards added here to
illustrate multi-version support):

* 3.10.0-693.x (CentOS 7.4)
	* Vendored sources are used with all CentOS 7.4 patch levels,
		and prior CentOS 7 patch levels.
* 3.10.0-862.x (CentOS 7.5)
	* Vendored sources are used with all CentOS 7.5 patch levels.
* 3.10.0-957.x (CentOS 7.6)
	* Vendored sources are used with all CentOS 7.6 patch levels.
* 3.10.0-1062.x (CentOS 7.7)
	* Vendored sources are used with all CentOS 7.7 patch levels, and future
		CentOS 7.x patch levels.
	* NOTE: May require further patching for OFED 4.4 and OFED 4.5.
* 4.4.162-94.72 (OpenSUSE 42.3)
	* Vendored sources are from the distro.
* 4.4.165-81 (SLES 12 SP 3)
	* Vendored sources are from the distro.
* 4.12.14-95.45.1 (SLES 12 SP 4)
	* Vendored sources are from the distro.
* 4.15.0-52.56 (Ubuntu 18)
	* Vendored sources are from the distro.
* 4.15.0-76.86 (Ubuntu 18)
	* Vendored sources are from the distro.
* 5.0.0-37.40 (Ubuntu 19)
	* Vendored sources are from the distro.

If a build attempted on a kernel or OFED version not listed here, it is not
guaranteed to work.


# Building

## Building for DEB-based distros

It is expected that OFED is installed using the 'DKMS' feature.

    sudo ./mlnxofedinstall --add-kernel-support --dkms

To generate the DKMS package, run `./build-deb.sh`. The output will reside in
`deb-dist`. The execution may have dependencies.


## Building for RPM-based distros

The Mellanox OFED needs to be installed on the target system before building.

In the RPM world, it is less common to find setups making use of DKMS.

Please use the `./build-rpm.sh` script. The result binary RPMs contains the OFED
version, kernel version, and VAST Data's `mlnx-nfsrdma` version. In the
following scheme:

`mlnx-nfsrdma-vast_<VAST-version>-OFED.<OFED version>_kernel_<Kernel version>`.

For example:

    mlnx-nfsrdma-vast_1.0_30_g994c965-OFED.4.7.1.0.0.1_kernel_3.10.0_1062.4.1.el7.x86_64.rpm

